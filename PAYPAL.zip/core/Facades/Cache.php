<?php

namespace Core\Facades;

use Core\Cache\CacheManager as CoreCache;

/**
 * Cache
 */
class Cache extends Facade
{
    protected static function getFacadeAccessor()
    {
        return CoreCache::class;
    }
}
