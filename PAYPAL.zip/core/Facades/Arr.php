<?php

namespace Core\Facades;

use Core\Support\Arr as SupportArr;

/**
 * Arr
 * 
 *@method static mixed dot($array, $prepend = '')
 *@method static array|null flatten($array, $depth = INF)
 *@method static mixed get($array, $key, $default = null)
 *@method static bool accessible($value)
 *@method static bool exists($array, $key)
 *@method static array|null set(&$array, $key, $value)
 *@method static array|null wrap($value)
 
 */
class Arr extends Facade
{
    protected static function getFacadeAccessor()
    {
        return SupportArr::class;
    }
}
