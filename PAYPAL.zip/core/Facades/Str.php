<?php

namespace Core\Facades;

use Core\Support\Str as SupportStr;
/**
 * Str
 * 
 */
class Str extends Facade{
    protected static function getFacadeAccessor()
    {
        return SupportStr::class;
    }
}
