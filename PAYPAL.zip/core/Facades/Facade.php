<?php

namespace Core\Facades;

abstract class Facade
{
    public static function __callStatic($func, array $arguments = [])
    {
        $class = static::getFacadeAccessor();

        throw_when(!method_exists($class, $func), "Unknown methode $func in class " . $class, \BadMethodCallException::class);

        $container = \Core\Container::instance();

        $instance = $container->get($class);

        return $instance->{$func}(...$arguments);
    }

    protected static function getFacadeAccessor()
    {
        return "";
    }
}
