<?php

namespace Core\Facades;

use Core\Logger;

/**
 * File
 * 
 */
class Log extends Facade{
    protected static function getFacadeAccessor()
    {
        return Logger::class;
    }
}
