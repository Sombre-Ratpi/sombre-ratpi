<?php

namespace Core\Facades;

use Core\Config as CoreConfig;

/**
 * Config
 * @method static mixed get(string $key, $default = null)
 * @method static array|null set(string $key, $value)
 */
class Config extends Facade
{
    protected static function getFacadeAccessor()
    {
        return CoreConfig::class;
    }
}
