<?php

namespace Core\Facades;

use Core\Files\FileSystem;

/**
 * File
 * 
 */
class File extends Facade{
    protected static function getFacadeAccessor()
    {
        return FileSystem::class;
    }
}
