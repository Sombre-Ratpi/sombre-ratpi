<?php

namespace Core\Facades;

use Core\Http\Client\Response;
use Core\Http\Client\Request as ClientHTTP;

/**
 * Http
 * 
 * @method static Response get(string $url, array $query = [])
 */
class Http extends Facade
{
    protected static function getFacadeAccessor()
    {
        return ClientHTTP::class;
    }
}
