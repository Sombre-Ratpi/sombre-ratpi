<?php

namespace Core;

use Core\Exceptions\ContainerException;
use Core\ReflectionClass;

class Container
{
    private static $instance;
    private array $instances = [];

    public static function instance()
    {
        if (!self::$instance) self::$instance = new self;
        return self::$instance;
    }

    public function resolve(string $key)
    {
        if (!$this->exist($key)) $this->record($key);
        $instance = $this->instances[$key];
        if (is_callable($instance)) $instance = call_user_func_array($instance, [$this]);
        if (class_exists($key) && $instance === null) $instance = $this->__createInstance($key);

        return $this->instances[$key] = $instance;
    }

    public function records(array $keys): self
    {
        foreach ($keys as $key) {
            $this->record($key);
        }
        return $this;
    }
    public function record(string $key): self
    {
        throw_when($this->exist($key), "$key is already registered", ContainerException::class);
        $this->instances[$key] = null;
        return $this;
    }

    public function singleton(string $key, $instance): self
    {
        $this->instances[$key] = $instance;
        return $this;
    }

    public function get(string $key)
    {
        throw_when(!$this->exist($key), "$key not found in container", ContainerException::class);
        if ($this->resolved($key)) return $this->instances[$key];
        return $this->resolve($key);
    }

    public function resolved(string $key)
    {
        $instance = $this->instances[$key];
        return is_object($instance) && !is_callable($instance);
    }

    public function exist(string $key)
    {
        return array_key_exists($key, $this->instances);
    }

    private function __createInstance(string $key)
    {
        $reflection = new ReflectionClass($key);
        if (!$reflection->constructorAsDependencices()) return new $key();
        foreach ($reflection->getConstructorParams() as $param) {
            $args[] = ($param === self::class) ? $this : $this->resolve($param);
        }
        return $reflection->newInstanceArgs($args ?? []);
    }
}
