<?php

namespace Core\Exceptions;

class ControllerNotFoundException extends Exception
{
}
