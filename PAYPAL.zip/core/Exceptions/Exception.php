<?php

namespace Core\Exceptions;

use Core\Contracts\ExceptionInterface;

class Exception extends \Exception implements ExceptionInterface
{
}
