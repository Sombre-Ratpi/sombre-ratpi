<?php

namespace Core\Exceptions;

class RouteNotFoundException extends Exception
{
}
