<?php

namespace Core\Exceptions;

use Core\Exceptions\Exception;

class ContainerException extends Exception
{
}
