<?php

namespace Core\Cache;

use Core\Support\Carbon;
use Core\Files\FileSystem;
use Core\Contracts\CacheInterface;

class FileStoreCache implements CacheInterface
{
    private FileSystem $files;
    private string $directory;

    public function __construct(FileSystem $files, string $directory)
    {
        $this->files = $files;
        $this->directory = $directory;
    }

    public function has(string $key): bool
    {
        return !is_null($this->get($key));
    }

    public function get(string $key,  $default = null)
    {
        return $this->getPayload($key)['data'] ?? null;
    }

    public function set(string $key, $value, int $seconds)
    {
        $this->ensureCacheDirectoryExists($path = $this->path($key));
        $result = $this->files->put(
            $path,
            $this->expiration($seconds) . serialize($value)
        );
        if ($result !== false && $result > 0) return true;
        return false;
    }

    public function forget(string $key)
    {
        if ($this->files->exists($file = $this->path($key))) {
            return $this->files->delete($file);
        }
        return false;
    }

    protected function getPayload(string $key)
    {
        try {
            $expire = substr($contents = $this->files->get($this->path($key)), 0, 10);
        } catch (\Throwable $th) {
            return $this->emptyPayload();
        }
        if ($this->currentTime() >= $expire) {
            $this->forget($key);
            return $this->emptyPayload();
        }
        try {
            $data = unserialize(substr($contents, 10));
        } catch (\Exception $e) {
            $this->forget($key);

            return $this->emptyPayload();
        }
        $time = $expire - $this->currentTime();
        return compact('data', 'time');
    }

    protected function emptyPayload()
    {
        return ['data' => null, 'time' => null];
    }

    protected function ensureCacheDirectoryExists(string $path)
    {
        return $this->files->ensureDirectoryExists($path);
    }

    protected function path(string $key)
    {
        return $this->directory . '/' . sha1($key);
    }

    protected function expiration($seconds)
    {
        $time = $this->availableAt($seconds);
        return $seconds === 0 || $time > 9999999999 ? 9999999999 : $time;
    }

    protected function availableAt($delay = 0)
    {
        return Carbon::now()->addRealSeconds($delay)->getTimestamp();
    }
    protected function currentTime()
    {
        return Carbon::now()->getTimestamp();
    }
}
