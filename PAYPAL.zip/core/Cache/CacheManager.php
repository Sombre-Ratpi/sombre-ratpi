<?php

namespace Core\Cache;

use Core\Contracts\CacheInterface;
use Closure;

class CacheManager
{
    private CacheInterface $cache;

    public function __construct(CacheInterface $cache)
    {
        $this->cache = $cache;
    }

    public function has(string $key)
    {
        return $this->cache->has($key);
    }
    public function get(string $key, $default  = null)
    {
        return $this->cache->get($key, $default);
    }

    public function rememberForever(string $key, Closure $callback)
    {
        return $this->remember($key, 0, $callback);
    }
    public function remember(string $key, int $second, Closure $callback)
    {
        $value = $this->get($key);
        if (!is_null($value)) {
            return $value;
        }

        $this->put($key, $value = $callback(), $second);

        return $value;
    }

    public function put(string $key, $data, int $seconds = 0)
    {
        return $this->cache->set($key, $data, $seconds);
    }
}
