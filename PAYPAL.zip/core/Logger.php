<?php

namespace Core;

use Core\Date;
use Core\Files\FileSystem;

class Logger
{
    private FileSystem $file;

    public function __construct(FileSystem $file)
    {
        $this->file = $file;
    }
    public function debug($value)
    {
        $this->_logger($value, "DEBUG");
    }

    public function info($value)
    {
        $this->_logger($value, "INFO", "log/info.log");
    }

    private function _logger($data, string $type = null,  string $path = "log/app.log")
    {
        return $this->file->append(
            storage_path($path),
            new Date() . ".$type: " . $this->_formatValue($data) . PHP_EOL
        );
    }

    private function _formatValue($data)
    {
        if (is_string($data)) return $data;
        $string = "[";
        foreach ($data as $key => $value) {
            if (is_array($value)) $value = $this->_formatValue($value);
            $string .= "$key => $value";
            if ($key !== array_key_last($data)) $string .= ", ";
        }
        $string .= "]";
        return $string;
    }
}
