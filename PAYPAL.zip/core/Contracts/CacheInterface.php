<?php

namespace Core\Contracts;

interface CacheInterface
{
    public function set(string $path, $value, int $time);
    public function has(string $path): bool;
    public function get(string $path, $default = null);
}
