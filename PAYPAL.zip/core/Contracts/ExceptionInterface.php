<?php

namespace Core\Contracts;

interface ExceptionInterface
{
}
