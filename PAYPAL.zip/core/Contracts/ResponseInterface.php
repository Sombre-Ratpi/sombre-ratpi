<?php

namespace Core\Contracts;

interface ResponseInterface
{
    public function body(): string;
    public function json();
    public function status(): int;
    public function ok(): bool;
    public function successful(): bool;
    public function failed(): bool;
    public function serverError(): bool;
    public function clientError(): bool;
    public function header(string $header): string;
    public function headers(): array;
}
