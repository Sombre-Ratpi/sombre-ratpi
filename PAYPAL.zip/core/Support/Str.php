<?php

namespace Core\Support;

class Str
{
    public function contains(string $haystack, string $needle)
    {
        return strpos($haystack, $needle) !== false;
    }
    
    public function minifier(string $code): ?string
    {
        if (is_null($code)) return null;
        $search = [
            // Remove whitespaces after tags
            '/\>[^\S ]+/s',

            // Remove whitespaces before tags
            '/[^\S ]+\</s',

            // Remove multiple whitespace sequences
            '/(\s)+/s',

            // Removes comments
            '/<!--(.|\s)*?-->/'
        ];
        $replace = ['>', '<', '\\1'];
        $code = preg_replace($search, $replace, $code);
        return $code;
    }

    public function e($string)
    {
        $string = htmlentities($string, ENT_QUOTES, 'UTF-8');
        $string = trim($string);
        $string = htmlspecialchars($string);
        return $string;
    }
}
