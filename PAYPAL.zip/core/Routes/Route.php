<?php

namespace Core\Routes;

use Core\Container;
use Core\Exceptions\{ControllerNotFoundException};
use Core\Facades\Arr;

class Route
{
    private const DELIMIT_PARAMETER_FOR_CERTAIN_REQUESTS = "#";
    private const NOT_CLASS_HINTS = ['string', 'int'];
    private ?string $prefix  = null;
    private string $uri;
    /** @var callable|string[]|string*/
    private $action;
    private array $middlewares = [];

    public function __construct(string $method, string $uri, $action)
    {
        $this->method = $method;
        $this->uri = $this->removeSlash($uri);
        $this->action = $action;
    }

    public function match(string $url)
    {
        $path = $this->uri;
        $regex = "#^$path$#";
        if (!preg_match($regex, $url, $matches)) return false;

        array_shift($matches);
        $this->matches = $matches;
        return true;
    }

    public function middleware($middlewares)
    {
        $this->middlewares = array_merge($this->middlewares, Arr::wrap($middlewares));
    }

    public function  prefix(string $value)
    {
        $this->prefix = $value;
        $this->uri = $this->removeSlash($this->prefix) . '/' . $this->uri;
    }

    public function resolveAction(Container $container)
    {
        throw_when($this->action === null, "Action is required for this route");

        if (is_array($this->action)) {
            return $this->__resolveArrayAction($container);
        }
        if (is_callable($this->action)) {
            dd($this->action);
            return ($this->action)();
        }

        if (is_string($this->action)) {
            $this->action = [$this->action, "__invoke"];
            return $this->resolveAction($container);
        }

        throw_when(true, "Unexpected value \"" . $this->action . "\" for route action ", \UnexpectedValueException::class);
    }

    private function __resolveArrayAction(Container $container)
    {
        [$controller, $action] = $this->action;
        if (strpos($controller, self::DELIMIT_PARAMETER_FOR_CERTAIN_REQUESTS)) {
            [$controller, $params] = explode(self::DELIMIT_PARAMETER_FOR_CERTAIN_REQUESTS, $controller);
        }

        throw_when(!file_exists(root_path(lcfirst($controller . '.php'))), "Controller $controller not found", ControllerNotFoundException::class);

        $controllerInstance = $container->resolve($controller);
        $method = new \ReflectionMethod($controllerInstance, $action);

        throw_when(!$method->isPublic(), "$controller::$action is not accessible", \BadMethodCallException::class);

        $parameters = $method->getParameters();
        $dependencies = [];
        foreach ($parameters as $parameter) {
            $hint = $parameter->getType()->getName();
            if (in_array($hint, self::NOT_CLASS_HINTS)) break;
            $dependenceClass = $hint;
            $dependencies[] = $container->resolve($dependenceClass);
        }

        if (isset($params)) {
            $dependencies = array_merge($dependencies, Arr::wrap($params));
        }

        return $controllerInstance->{$action}(...$dependencies);
    }

    public function getMiddlewares()
    {
        return $this->middlewares;
    }
    public function getPrefix()
    {
        return $this->prefix;
    }

    private function removeSlash(string $uri)
    {
        return $uri !== "/" ? trim($uri, '/') : $uri;
    }
}
