<?php

namespace Core\Routes;

use Core\Actions\RedirectAction;
use Core\Http\Request;
use Core\Exceptions\{RouteNotFoundException};
use Core\Facades\Arr;

class Router
{
    private const GET = "GET";
    private const POST = "POST";
    /** @var Route[] */
    private $routes = [];
    private array $middlewares = [];
    private ?string $prefix = null;

    public function get(string $uri, $action): Route
    {
        return $this->addRoute(self::GET, $uri, $action);
    }

    public function post(string $uri, $action): Route
    {
        return $this->addRoute(self::POST, $uri, $action);
    }

    public function addRoute(string $method, string $uri, $action): Route
    {
        if (!isset($this->routes[$method])) $this->routes[$method] = [];
        $route = new Route($method, $uri, $action);
        $this->routes[$method][] = $route;
        !empty($this->middlewares) && $route->middleware($this->middlewares);
        !is_null($this->prefix) && $route->prefix($this->prefix);
        return $route;
    }

    public function redirect(string $from, string $to)
    {
        $this->get($from, RedirectAction::class . "#$to");
    }

    public function middleware($middlewares): self
    {
        $this->middlewares = Arr::wrap($middlewares);
        return $this;
    }
    public function prefix($prefix): self
    {
        $this->prefix = $prefix;
        return $this;
    }

    public function group(callable $func): self
    {
        call_user_func($func, $this);
        $this->middlewares = [];
        return $this;
    }

    public function loadRoutes(string $path)
    {
        $routes = require $path;
        return $routes($this);
    }

    public function run(Request $request): Route
    {
        $uri = $request->uri();
        $method = $request->method();

        throw_when(!isset($this->routes[$method]), "Unknown request method " . $method);
        foreach ($this->routes[$method] as $route) {
            if ($route->match($uri)) {
                return $route;
            }
        }
        throw_when(!isset($this->routes[$method][$uri]), "Unknown route $uri for $method method", RouteNotFoundException::class);
    }
}
