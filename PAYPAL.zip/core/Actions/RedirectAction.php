<?php

namespace Core\Actions;

use Core\Http\Response;

class RedirectAction
{
    public function __invoke(Response $response, string $to)
    {
        $response->redirect($to);
    }
}
