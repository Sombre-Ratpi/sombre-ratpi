<?php

namespace Core;

class ReflectionClass
{
    private array $args = [];
    private string $class;
    private \ReflectionClass $reflection;
    /**@var \ReflectionMethod|null */
    private $constructor;

    public function __construct(string $class)
    {
        $this->class = $class;
        $this->reflection = new \ReflectionClass($class);
    }

    public function constructorAsDependencices()
    {
        $this->constructor = $this->reflection->getConstructor();
        return $this->constructor !== null;
    }

    public function getConstructorParams(): array
    {
        if ($this->constructor === null) return [];
        $params = $this->constructor->getParameters();
        foreach ($params as $param) {
            $this->args[] = $param->getType()->getName();
        }
        return $this->args;
    }

    public function newInstanceArgs(array $args)
    {
        return $this->reflection->newInstanceArgs($args);
    }
}
