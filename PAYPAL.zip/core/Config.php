<?php

namespace Core;

use Core\Facades\Arr;

class Config
{
    private array $data = [];

    public function setData(array $array)
    {
        $this->data = $array;
    }
    public function get(string $key, $default = null)
    {
        return Arr::get($this->data, $key, $default);
    }

    public function set(string $key, $value): ?array
    {
        return Arr::set($this->data, $key, $value);
    }
}
