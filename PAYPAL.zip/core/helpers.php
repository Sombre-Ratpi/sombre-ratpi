<?php

use Core\Logger;
use Core\Container;
use Core\Support\Carbon;
use Core\Facades\{Arr, Config, File, Str, Log};


if (!function_exists('now')) {
    function now()
    {
        return new Carbon();
    }
}
if (!function_exists('url')) {
    function url(string $uri)
    {
        return rtrim(Config::get('app.url'), '/') . '/' . ltrim($uri, '/');
    }
}
if (!function_exists('unix_slash')) {
    function unix_slash(string $path)
    {
        return str_replace(["\\", "\\/", "//", "\\\\"], "/", $path);
    }
}
if (!function_exists('win_slash')) {
    function win_slash(string $path)
    {
        return str_replace(["/", "\\/", "//", "\\\\"], "\\", $path);
    }
}

if (!function_exists('parse_slash')) {
    function parse_slash(string $path)
    {
        if (PHP_OS === "Linux") return unix_slash($path);
        if (PHP_OS === "WINNT") return win_slash($path);
    }
}

if (!function_exists('config')) {
    function config(string $key, $default = null)
    {
        return Config::get($key, $default);
    }
}
if (!function_exists('mix')) {
    function mix(string $path)
    {
        $mix_manifest_path = public_path('mix-manifest.json');
        if (!File::exists($mix_manifest_path)) return $path;
        $manifest = File::get($mix_manifest_path);
        $manifestFiles = Arr::parseJson($manifest);
        return $manifestFiles[$path] ?? $path;
    }
}
if (!function_exists('value')) {
    /**
     * Return the default value of the given value.
     *
     * @param  mixed  $value
     * @return mixed
     */
    function value($value)
    {
        return $value instanceof Closure ? $value() : $value;
    }
}

if (!function_exists('minifier')) {
    function minifier(string $code): ?string
    {
        return Str::minifier($code);
    }
}
if (!function_exists('e')) {
    function e($string)
    {
        return Str::e($string);
    }
}
if (!function_exists('logger')) {
    function logger($value = null)
    {
        if (is_null($value)) return app(Logger::class);
        return Log::debug($value);
    }
}
if (!function_exists('public_path')) {
    function public_path(string $file = null)
    {
        return root_path("public/$file");
    }
}
if (!function_exists('database_path')) {
    function database_path(string $file = null)
    {
        return root_path("database/$file");
    }
}
if (!function_exists('config_path')) {
    function config_path(string $file = null)
    {
        return root_path("config/$file");
    }
}
if (!function_exists('resources_path')) {
    function resources_path(string $file = null)
    {
        return root_path("resources/$file");
    }
}
if (!function_exists('routes_path')) {
    function routes_path(string $file = null)
    {
        return root_path("routes/$file");
    }
}
if (!function_exists('storage_path')) {
    function storage_path(string $file = null)
    {
        return root_path("storage/$file");
    }
}

if (!function_exists('app_path')) {
    function app_path(string $file = null)
    {
        return root_path("app/$file");
    }
}

if (!function_exists('root_path')) {
    function root_path(string $file = null)
    {
        $path =  dirname(__DIR__) . "/$file";
        return parse_slash($path);
    }
}

if (!function_exists('throw_when')) {
    /**
     * throw_when
     *
     * @param bool $statement 
     * @param string|null $message 
     * @param string|null $exception
     * @throws \Exception
     * @return null
     */
    function throw_when(bool $statement, string $message = null, string $exception = null)
    {
        if (!$statement) return null;
        if ($exception === null) $exception = \Exception::class;
        throw new $exception($message);
    }
    if (!function_exists('app')) {
        /**
         * Get the available container instance.
         *
         * @param  string|null  $abstract
         * @param  array  $parameters
         * @return mixed
         */
        function app($abstract = null, array $parameters = [])
        {
            if (is_null($abstract)) {
                return Container::instance();
            }

            return Container::instance()->resolve($abstract, $parameters);
        }
    }
}
