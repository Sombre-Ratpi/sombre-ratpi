<?php

namespace Core\Concerns;

trait ApplicationTrait
{

    public function getDebug()
    {
        return $this->debug;
    }

    public function setDebug(bool $debug)
    {
        return $this->debug = $debug;
    }

    public function getEnvironment()
    {
        return $this->environment;
    }

    public function setEnvironment(string $environment)
    {
        return $this->environment = $environment;
    }
    public function getAppName()
    {
        return $this->appName;
    }

    public function setAppName(string $appName)
    {
        return $this->appName = $appName;
    }
}
