<?php

namespace Core\Template;

use Core\Files\FileSystem;

class CacheManager
{
    private FileSystem $files;
    private string $directory;

    public function __construct(FileSystem $files, string $directory)
    {
        $this->files = $files;
        $this->directory = $directory;
    }
    public function has(string $key)
    {
        return $this->files->exists($this->path($key));
    }

    public function get(string $key, $default = null)
    {
        return $this->files->get($this->path($key)) ?? $default;

    }
    public function put(string $key, $value)
    {
        return $this->files->put($this->path($key), $value);
    }

    public function clear()
    {
        return rmdir($this->directory);
    }
    protected function path(string $key)
    {
        return  rtrim($this->directory) . '/'  . sha1($key) . '.php';
    }
}
