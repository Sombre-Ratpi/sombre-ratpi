<?php

namespace Core\Template;

use Core\Files\FileSystem;
use Core\Template\CacheManager;

class TemplateCompiler
{
    private string $fileExtension = ".view.php";
    private string $namespace = "views";
    private bool $cacheEnabled = false;
    private array $blocks = [];
    private FileSystem $files;
    private CacheManager $cache;
    public function __construct(FileSystem $files, CacheManager $cache)
    {
        $this->files = $files;
        $this->cache = $cache;
    }

    public function render(string $view, array $params = []): string
    {
        throw_when(
            !file_exists($view = $this->path($view)),
            "View $view don't exit in " . $this->getNamespace(),
            \UnexpectedValueException::class
        );

        return (string) $this->evalCode($this->cache($view), $params);
    }

    protected function cache(string $view)
    {
        if (!$this->cacheEnabled) return $this->generateCode($view);

        if ($this->cache->has($view)) return $this->cache->get($view);
        $this->cache->put($view, $code = minifier($this->generateCode($view)));

        return $code;
    }

    public function enableCache(bool $state = true): self
    {
        $this->cacheEnabled = $state;
        return $this;
    }

    protected function generateCode(string $view)
    {
        $code =  $this->includeFiles($view);
        return $this->compileCode($code);
    }

    protected function evalCode(string $code, $params = []): string
    {
        ob_start();
        extract($params);
        eval(PHP_END_TAG . $code . PHP_START_TAG);
        return ob_get_clean();
    }


    protected function clearCache()
    {
        $this->cache->clear();
    }

    protected function compileCode($code)
    {
        $code = $this->removeComments($code);
        $code = $this->compileBlock($code);
        $code = $this->compileYield($code);
        $code = $this->compileEscapedEchos($code);
        $code = $this->compileEchos($code);
        $code = $this->compilePHP($code);
        return $code;
    }

    protected function includeFiles(string $file)
    {
        $code = $this->files->get($file);

        preg_match_all('/{% ?(extends|include) ?\'?(.*?)\'? ?%}/i', $code, $matches, PREG_SET_ORDER);
        foreach ($matches as [$tag, $property, $view]) {
            $code = str_replace($tag, $this->includeFiles($this->path($view)), $code);
        }

        $code = preg_replace('/{% ?(extends|include) ?\'?(.*?)\'? ?%}/i', '', $code);
        return $code;
    }

    protected function compileBlock(string $code)
    {
        preg_match_all('/{% ?block ?(.*?) ?%}(.*?){% ?endblock ?%}/is', $code, $matches, PREG_SET_ORDER);

        foreach ($matches as $value) {
            if (!array_key_exists($value[1], $this->blocks)) $this->blocks[$value[1]] = '';
            if (strpos($value[2], '@parent') === false) {
                $this->blocks[$value[1]] = $value[2];
            } else {
                $this->blocks[$value[1]] = str_replace('@parent', $this->blocks[$value[1]], $value[2]);
            }
            $code = str_replace($value[0], '', $code);
        }
        return $code;
    }
    protected function compilePHP($code)
    {
        return preg_replace('~\{%\s*(.+?)\s*\%}~is', PHP_START_TAG . ' $1 ' . PHP_END_TAG, $code);
    }
    protected function compileEchos($code)
    {
        return preg_replace('~\{!!\s*(.+?)\s*\!!}~is', PHP_START_TAG . ' echo $1 ' . PHP_END_TAG, $code);
    }
    protected function removeComments($code)
    {
        return preg_replace('~\{--\s*(.+?)\s*\--}~is', '', $code);
    }

    protected function compileEscapedEchos($code)
    {
        return preg_replace('~\{{\s*(.+?)\s*\}}~is', PHP_START_TAG . ' echo e($1) ' .
            PHP_END_TAG, $code);
    }

    protected function compileYield($code)
    {
        foreach ($this->blocks as $block => $value) {
            $code = preg_replace('/{% ?yield ?' . $block . ' ?%}/', $value, $code);
        }
        return preg_replace('/{% ?yield ?(.*?) ?%}/i', '', $code);
    }

    protected function getNamespace()
    {
        return resources_path($this->namespace);
    }

    protected function path(string $view): string
    {
        return resources_path(
            $this->namespace . "\\" . str_replace('.', '\\', $view) . $this->fileExtension
        );
    }
}
