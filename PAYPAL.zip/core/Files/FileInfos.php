<?php

namespace Core\Files;

class FileInfos
{

    private string $path;
    private string $dirname;
    private string $basename;
    private string $extension;
    private string $filename;

    public function __construct(string $path)
    {
        $this->path = parse_slash($path);
        $this->hydrate();
    }

    protected function hydrate()
    {
        $infos = pathinfo($this->path);
        [
            "dirname" =>  $this->dirname,
            "basename" =>  $this->basename,
            "extension" =>  $this->extension,
            "filename" =>  $this->filename,
        ] = $infos;
    }

    public function getPath()
    {
        return $this->path;
    }
    public function getDirname()
    {
        return $this->dirname;
    }
    public function getBasename()
    {
        return $this->basename;
    }
    public function getExtension()
    {
        return $this->extension;
    }
    public function getFilename()
    {
        return $this->filename;
    }
}
