<?php

namespace Core\Files;

class FileSystem
{
    public function ensureDirectoryExists(string $path)
    {
        if (!$this->directoryExists($directory = dirname($path)))
            $this->makeDirectory($directory, 0775, true);
    }
    public function files(string $dir, bool $root = false): array
    {
        $files = scandir($dir);

        if (!$root) $files =  array_filter($files, fn ($file) => strpos($file, '.') !== 0);

        $files = array_values($files);

        return array_map(fn ($file) => new FileInfos($dir . "\\" . $file), $files);
    }

    public function create(string $path): bool
    {
        if ($this->exists($path)) return true;
        if (!$this->directoryExists(dirname($path))) $this->makeDirectory(dirname($path));
        return touch($path);
    }

    public function makeDirectory(
        string $path,
        int $permissions = 0777,
        bool $recursive = false
    ): bool {
        return mkdir($path, $permissions, $recursive);
    }

    public function directoryExists(string $path): bool
    {
        return is_dir($path);
    }

    public function exists(string $path): bool
    {
        return file_exists($path);
    }

    public function put(string $path, $value, int $flags = 0)
    {
        if (!$this->exists($path)) $this->create($path);
        return file_put_contents($path, $value, $flags);
    }

    public function append(string $path, $value)
    {
        return $this->put($path, $value, FILE_APPEND);
    }

    public function get(string $path): string
    {
        return file_get_contents($path);
    }

    public function delete($paths)
    {
        $paths = is_array($paths) ? $paths : func_get_args();

        $success = true;

        foreach ($paths as $path) {
            try {
                if (! @unlink($path)) {
                    $success = false;
                }
            } catch (\ErrorException $e) {
                $success = false;
            }
        }

        return $success;
    }
}
