<?php

namespace Core;

use Core\Files\{FileSystem};
use Core\Support\{Arr, Str};
use Core\Routes\{Route, Router};
use Core\Http\{Request, Response};
use Core\Concerns\ApplicationTrait;
use Core\Http\Client\Request as ClientRequest;
use Core\Cache\{CacheManager as Cache, FileStoreCache};
use Core\Template\{CacheManager as TemplateCacheManager, TemplateCompiler};

class Application
{
    use ApplicationTrait;

    private const MIDDLEWARE_NEXT_FLAG = "NEXT";
    private Container $container;
    private FileSystem $file;
    private Config $config;
    private string $environment = "development";
    private string $appName = "Breeze";
    private bool $debug = true;

    public function __construct(Container $container, FileSystem $file, Config $config)
    {
        $this->container = $container;
        $this->file = $file;
        $this->config = $config;
    }
    public function run()
    {
        $this->register();
        $this->boot();

        /** @var Request $router  */
        $request = $this->get(Request::class);
        /** @var Router $router  */
        $router = $this->get(Router::class);

        $test_routes_path = routes_path('test.web.php');

        $router->loadRoutes(routes_path('web.php'));
        if (file_exists($test_routes_path)) {
            $router->loadRoutes($test_routes_path);
        }

        /** @var Response $response  */
        $response = $this->get(Response::class);
        $statusCode = Response::HTTP_OK;

        try {
            $route = $router->run($request);
        } catch (\Core\Exceptions\RouteNotFoundException $e) {
            $statusCode = Response::HTTP_NOT_FOUND;
            $body = "Page not found";
        }

        if ($statusCode !== Response::HTTP_NOT_FOUND) {
            $this->handleRequestMiddlewares($route);
            $body = $route->resolveAction($this->container);
        }

        $response->withBody((string) $body, $statusCode);
        $response->send();
    }

    protected function register()
    {
        $this->container->records([
            Logger::class,
            Request::class,
            Response::class,
            Router::class,
            Date::class,
            Arr::class,
            Str::class,
            ClientRequest::class
        ]);

        $this->container->singleton(Cache::class, function (Container $container) {
            return new Cache(
                new FileStoreCache(
                    $container->get(FileSystem::class),
                    $this->config->get('cache.directory')
                )
            );
        });

        $this->container->singleton(
            TemplateCacheManager::class,
            fn (Container $container) => new TemplateCacheManager(
                $container->get(FileSystem::class),
                $this->config->get('view.cache.directory')
            )
        );

        $this->container->singleton(TemplateCompiler::class, function (Container $container) {
            return (new TemplateCompiler(
                $container->get(FileSystem::class),
                $container->get(TemplateCacheManager::class),
            ))->enableCache($this->config->get('view.cache.enable'));
        });
    }
    protected function boot()
    {
        $files =  $this->file->files(config_path());
        $configs = [];
        foreach ($files as $file) {
            $configs[$file->getFilename()] = require $file->getPath();
        }
        $this->config->setData($configs);
        $this->setDebug($this->config->get("app.debug", false));

        if ($this->debug) {
            $whoops = new \Whoops\Run;
            $whoops->pushHandler(new \Whoops\Handler\PrettyPageHandler);
            $whoops->register();
        }
    }

    protected function handleRequestMiddlewares(Route $route)
    {
        $middlewares = $this->config->get('app.middlewares');
        foreach ($route->getMiddlewares() as $middleware) {
            $options = [];
            if ($this->get(Str::class)->contains($middleware, ':')) {
                $parts = explode(':', $middleware);
                $middleware = $parts[0];
                $options[] = $this->formatMiddlewareOption($parts[1]);
            }
            throw_when(
                !array_key_exists($middleware, $middlewares),
                "Unknown middleware $middleware",
                \UnexpectedValueException::class
            );

            $class = $middlewares[$middleware];

            $instance = $this->container->resolve($class);

            $response = $instance->handle($this->container, self::MIDDLEWARE_NEXT_FLAG, ...$options);

            if ($response !== self::MIDDLEWARE_NEXT_FLAG) {
                break;
            };
        }

        return self::MIDDLEWARE_NEXT_FLAG;
    }

    protected function formatMiddlewareOption(string $raw)
    {
        if (!str_contains($raw, ',')) return $raw;

        $data = explode(',', $raw);
        return $this->get(Arr::class)
            ->map($data, fn ($item) => trim($item));
    }
    protected function get(string $abstract)
    {
        return $this->container->get($abstract);
    }
}
