<?php

namespace Core\Http;

use Core\Facades\Arr;

class Request
{
    private string $ip;
    private string $uri;
    private string $method;
    private string $hostname;

    public function __construct()
    {
        $this->hydrate();
    }

    public function ip()
    {
        return $this->ip;
    }
    public function hostname()
    {
        return $this->hostname;
    }

    public function uri()
    {
        return $this->uri === "/" ? '/' : trim($this->uri, '/');
    }
    public function method()
    {
        return $this->method;
    }

    public function query(?string $key, $default = null)
    {
        return $this->dataGet($_GET, $key, $default);
    }

    public function all()
    {
        return $this->input();
    }

    public function input(?string $key = null, $default = null)
    {
        return $this->dataGet($_POST, $key, $default);
    }

    public function server(?string $key = null, $default = null)
    {
        return $this->dataGet($_SERVER, $key, $default);
    }

    protected function dataGet(array $data, ?string $key = null, $default)
    {
        if (is_null($key)) return $data;
        return Arr::get($data, $key, $default);
    }

    protected function hydrate()
    {
        $this->uri  = $this->server('REQUEST_URI') ?? "/";
        $this->method  = $this->server('REQUEST_METHOD') ?? "/";

        $this->ip = !empty($this->server('HTTP_CLIENT_IP')) ?
            $this->server('HTTP_CLIENT_IP') : (!empty($this->server('HTTP_X_FORWARDED_FOR')) ?
                $this->server('HTTP_X_FORWARDED_FOR') : $this->ip = $this->server('REMOTE_ADDR'));

        $this->hostname = gethostbyaddr($this->ip);
    }
}
