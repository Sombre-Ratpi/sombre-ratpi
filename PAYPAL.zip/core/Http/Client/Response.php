<?php

namespace Core\Http\Client;

use Core\Facades\Arr;
use Core\Concerns\ResponseTrait;
use Core\Contracts\ResponseInterface;

class Response implements ResponseInterface
{
    use ResponseTrait;
    
    private string $body;
    private int $status;
    private array $headers;

    public function __construct(string $body, int $status = 202, array $option = [])
    {
        $this->body = $body;
        $this->status = $status;
        $this->headers = $this->parseHeaders(Arr::get($option, 'headers', ""));
    }
}
