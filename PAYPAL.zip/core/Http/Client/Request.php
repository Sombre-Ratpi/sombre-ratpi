<?php

namespace Core\Http\Client;

use Core\Facades\Arr;
use Core\Facades\Config;

class Request
{
    private const GET = "GET";
    private const POST = "GET";
    private const METHODS_AUTHORIZED = ["GET", "POST"];
    private const SEND_QUERY_OPTION = "QUERY";
    private const SEND_DATA_OPTION = "POST_DATA";
    /**
     * Issue a GET request to the given URL.
     *
     * @param  string  $url
     * @param  array|string|null  $query
     * @return Response
     */
    public function get(string $url, array $query = [])
    {
        return $this->sendRequest(self::GET, $url, [self::SEND_QUERY_OPTION => $query]);
    }

    public function post(string $url, array $data)
    {
        return $this->sendRequest(self::POST, $url, [self::SEND_DATA_OPTION => $data]);
    }

    protected function sendRequest(string $method, string $url, array $options)
    {
        throw_when(!in_array($method, self::METHODS_AUTHORIZED), "Method $method not authorized");

        $curl = curl_init();

        // dd($this->formatUrl($url, $options[self::SEND_QUERY_OPTION] ?? []));

        // OPTIONS:
        $this->setOptions(
            $curl,
            [
                'url' => $this->formatUrl($url, $options[self::SEND_QUERY_OPTION] ?? []),
                "is_post_request" => $method === self::POST,
                "data" => $options[self::SEND_DATA_OPTION] ?? []
            ]
        );

        // EXECUTE:
        $curl_response = curl_exec($curl);

        throw_when($curl_response === false, "cURL Connection Failure");

        $curl_infos = curl_getinfo($curl);
        $header_size = $curl_infos['header_size'];
        $headers = substr($curl_response, 0, $header_size);

        curl_close($curl);

        return new Response(
            (string) substr($curl_response, $header_size),
            $curl_infos['http_code'],
            ["headers" => $headers]
        );
    }

    protected function formatUrl(string $url, $query = [])
    {
        if (!$this->isAFullUrl($url)) $url = url($url);
        if (!empty($query)) $url = sprintf("%s?%s", $url, Arr::queryString($query));
        return $url;
    }

    protected function isAFullUrl(string $url)
    {
        return str_contains($url, 'http');
    }

    protected function setOptions($curl, array $options = [])
    {
        isset($options['url']) && curl_setopt($curl, CURLOPT_URL, $options['url']);
        if ($options['is_post_request']) {
            curl_setopt($curl, CURLOPT_POST, 1);
            if (!empty($data = $options['data']))
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }

        curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    }
}
