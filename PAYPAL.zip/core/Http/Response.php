<?php

namespace Core\Http;

use Core\Concerns\ResponseTrait;
use Core\Contracts\ResponseInterface;

class Response implements ResponseInterface
{
    use ResponseTrait;

    public const HTTP_OK = 200;
    public const HTTP_NOT_FOUND = 404;
    private ?string $body = null;
    private int $status;
    private array $headers = [];

    public function redirect(string $url)
    {
        $this->withHeaders([
            "HTTP/1.1" => "301 Moved Permanently",
            "Location:" => $url
        ]);
        $this->withStatus(301)
            ->send();
    }

    public function withHeader(string $key, string $value): self
    {
        $this->headers[$key] = $value;
        return $this;
    }

    public function withHeaders(array $headers): self
    {
        foreach ($headers as $key => $value) {
            $this->withHeader($key, $value);
        }
        return $this;
    }

    public function withBody(string $body, int $code = 200): self
    {
        $this->body = $body;
        $this->status = $code;
        return $this;
    }

    public function withStatus(int $status): self
    {
        $this->status = $status;
        return $this;
    }

    public function send()
    {
        $this->formatHeaders();
        http_response_code($this->status);
        if ($this->body) echo (string) $this->body;
        exit;
    }
}
