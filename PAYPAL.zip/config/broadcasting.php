<?php

return [
    "telegram" => [
        "token" => '2048719990:AAHlU1xVUpwP0rj0ZIhpxAUgP2w--tK9Pa4',
        "channel" => '-1001645142041' // channel name e.g @test-channel or 1245122244855
    ]
];
