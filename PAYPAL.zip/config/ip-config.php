<?php
return [
    'inspector' => [
        'url' => 'https://api.db-ip.com/v2/free/'
    ]
];
