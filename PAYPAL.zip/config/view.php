<?php
return [
    'cache' => [
        'enable' => true,
        'directory' => storage_path('caches/views')
    ],
];
