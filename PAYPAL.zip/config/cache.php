<?php

return [
    "directory" => storage_path('caches/data')
];
