<?php

return [
    "from" => [
        "address" => "admin@test.ci",
        "name" => "PAYP"
    ],
    "to" => [
        "address" => "Gaetan1122@protonmail.com",
        "name" => "admin"
    ],
];
