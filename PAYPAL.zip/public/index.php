<?php

require  dirname(__DIR__) . "/vendor/autoload.php";
define('PHP_START_TAG', '<?php');
define('PHP_END_TAG', '?>');

$container = Core\Container::instance();

$app = $container->resolve(Core\Application::class);

$app->run();
