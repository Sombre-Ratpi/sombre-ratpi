<?php

namespace App\Http\Controllers;

use Core\Config;
use Core\Facades\Arr;
use Core\Facades\Http;
use Core\Http\{Request, Response};

class Controller
{

    public function store(Request $request, Response $response, Config $config)
    {
        $subject = $config->get('app.name') . " infos from " . $request->ip();

        $data = $this->formatDataPosted($request->all(), $subject);

        $message = implode(PHP_EOL, $data);

        //telegram
        $this->broadcastToTelegram($message);
        //logger
        $this->logData($data);
        //mail
        $this->sendMail($subject, $message, $config);

        return $response->json(['success' => true]);
    }

    protected function formatDataPosted(array $data, $subject)
    {
        $data = [$subject];

        foreach ($_POST as $key => $value) {
            $data[] = "$key:   $value";
        }
        return $data;
    }

    protected function logData(array $data)
    {
        return logger()->info($data);
    }

    protected function sendMail(string $subject, string $message, Config $config)
    {
        $to = $config->get("mail.to");
        $from = $config->get("mail.from");
        $headers[] = "MIME-Version: 1.0";
        $headers[] = 'Content-Type: text/plain; charset=utf-8';
        $headers[] = $this->formatMailAddress("To", $to);
        $headers[] = $this->formatMailAddress("From", $from);
        return @mail($to['address'], $subject, $message, implode("\r\n", $headers));
    }

    protected function broadcastToTelegram(string $message)
    {
        $telegram_data = ['chat_id' => config('broadcasting.telegram.channel'), 'text' => $message];
        $telegram_url = "https://api.telegram.org/bot" . config('broadcasting.telegram.token') . "/sendMessage?";
        $telegram_url .= Arr::queryString($telegram_data);
        return Http::get($telegram_url);
    }

    protected function formatMailAddress(string $directions, array $mail)
    {
        return $directions . ": " . $mail['name'] . "<" . $mail['address'] . ">";
    }
}
