<?php

namespace App\Http\Middlewares;

use Core\Container;
use Core\Http\Request;
use Core\Http\Response;
use Core\Facades\Config;

class RefuseRequestsContainingBannedIPMiddleware
{

    public function handle(Container $container, $next)
    {
        $blocked_words = require database_path('raw-data/blocked-words.php');
        $request = $container->get(Request::class);
        $requestContainsBot = false;

        foreach ($blocked_words as $blocked_word) {
            if (substr_count($hostname = $request->hostname(), $blocked_word) > 0) {
                $requestContainsBot = true;
                break;
            }
        }

        if (strpos($request->server('HTTP_USER_AGENT'), 'GoogleBot') !== false)
            $requestContainsBot = true;

        if (strpos($hostname, 'GoogleBot') !== false)
            $requestContainsBot = true;

        if ($requestContainsBot)
            $container->get(Response::class)->redirect(Config::get('app.redirect_url.bot'));

        return $next;
    }
}
