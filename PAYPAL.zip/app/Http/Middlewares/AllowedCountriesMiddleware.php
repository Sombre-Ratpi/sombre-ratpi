<?php

namespace App\Http\Middlewares;

use Core\Container;
use Core\Http\{Request, Response};
use Core\Facades\{Cache, Http, Config, Arr};

class AllowedCountriesMiddleware
{
    public function handle(Container $container, string $next, $allowed_countries)
    {
        $ip = $container->get(Request::class)->ip();
        $ip = in_array($ip, ['127.0.0.1','::1']) ? 'self' : $ip;
        $contry_code = Cache::remember(
            $ip . "-infos",
            60 * 5,
            function () use ($ip) {
                return Http::get(rtrim(Config::get('ip-config.inspector.url'), '/') . '/' . $ip)->json();
            }
        )['countryCode'] ?? null;

        if (!in_array($contry_code, Arr::wrap($allowed_countries)))
            $container->get(Response::class)->redirect(Config::get('app.redirect_url.bot'));

        return $next;
    }
}
