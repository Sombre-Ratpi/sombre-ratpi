<?php

namespace App\Http\Middlewares;

use Core\Container;
use Core\Http\Request;
use Core\Http\Response;
use Core\Facades\Config;

class RefuseRequestsContainingBots
{

    public function handle(Container $container, $next)
    {
        $banned_ips = require database_path("raw-data/banned-ips.php");

        if (in_array($container->get(Request::class)->ip(), $banned_ips)) {
            $container->get(Response::class)->redirect(Config::get('app.redirect_url.bot'));
        }

        return $next;
    }
}
